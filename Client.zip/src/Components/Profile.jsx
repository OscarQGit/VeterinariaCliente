import React from 'react'
import enconstruccion from '../imagenes/download.jpg';
const Profile = () => {
  return (
    
    <div>
      <h2>Profile</h2>
    <img src={enconstruccion} alt="BigCo Inc. logo"/>
  </div>
  )
}

export default Profile
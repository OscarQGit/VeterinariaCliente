import React from 'react'
import BasicBookAppointmentCalendar from './BasicBookAppointmentCalendar';

const BookAppointments = () => {
  return (
    <div>
        <BasicBookAppointmentCalendar/>
    </div>
  )
}

export default BookAppointments
import React from 'react'
import BasicCalendar from './BasicCalendar'

const VaccinationAppointments = () => {
  return (
    <div>
        <BasicCalendar/>
    </div>
  )
}

export default VaccinationAppointments
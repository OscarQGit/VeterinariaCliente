import React from 'react'
import BasicCalendar from './BasicCalendar'

const Appointments = () => {
  return (
    <div>
        <BasicCalendar/>
    </div>
  )
}

export default Appointments